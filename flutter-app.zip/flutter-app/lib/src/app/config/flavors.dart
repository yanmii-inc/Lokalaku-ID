enum Flavor { dev, stg, prd }

class F {
  static late final Flavor appFlavor;

  static String get name => appFlavor.name;

  static String get title {
    switch (appFlavor) {
      case Flavor.dev:
        return 'DEV {{ app_title }}';
      case Flavor.stg:
        return 'STG {{ app_title }}';
      case Flavor.prd:
        return '{{ app_title }}';
    }
  }
}
